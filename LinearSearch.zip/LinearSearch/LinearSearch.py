# linear search for text files
# array:texts containing text files
texts = ["text1.txt", "text2.txt", "text3.txt"]
# search-bar for user
print("----PROPER NAME WITH PROPER EXTENSION----")
search = str(input("\tsearch: "))
# linear searching mechanism
for i in range(len(texts)):
    if search == texts[i]:
        print(search, "\n\n|        Found!       |\n| At index texts[", i,"] | \n|     Position: ",i+1,"   |")
        bool = True
        print("\n CONTENT OF FILE: ")
        file = open(search, "r")
        print(file.read())
        break
    else:
        continue
if bool != True:
    print("Not found!")
