# importing libraries
import psutil                   # psutil--> python system and process utilities
from plyer import notification  # plyer--> accessing hardware features
import time                     # time--> controls system time

# declaring  "battery"
battery=psutil.sensors_battery()

# applying loop
while(True):
    percent=battery.percent
    notification.notify(
        title="BATTERY PERCENTAGE",
        message=str(percent)+" % Battery remaining",
        timeout=10
    )
    if str(percent)==100:
        notification.notify(
            title="BATTERY PERCENTAGE",
            message=str(percent)+" please plug-in the computer",
            timeout=0.5
        )
    time.sleep(60*60)
    continue