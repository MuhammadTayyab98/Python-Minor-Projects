'''
Taking value from the user
'''
# INTRO
print("----------------------------------------")
print("~~~~~~~~~WELCOME TO TAYYAB.COM~~~~~~~~~~ ")
print("----------------------------------------")
libskills=[1, 2, 3, 4]
libage=[17, 18, 19, 20, 21, 22, 23, 24, 25]
# taking the name of user
name1=input("Enter your first name (upper_case): ")
while name1 != name1.upper():
    name1 = input("Upper_case only!\nEnter again: ")
name2 = input("Enter your last name (upper_case): ")
while name2 != name2.upper():
    name2 = input("Upper_case only!\nEnter again: ")

# concatenate the name
name = f'{name1} {name2}'

# taking the age, ID, CGPA, skills
age = input("Enter your age: ")
while age not in libage:
    if age not in libage:
        print("Age must be of 18-24 and enter in figure format!")
        age = input("Enter your age: ")
    elif age in libage:
        print("Age confirmed!")
ID = int(input("Enter your ID: "))
CGPA = int(input("Enter your CGPA: "))
if (CGPA < 2.5):
    print("Sorry! You are not elligible for this post!")
else:
    print("\t-Choose one of your skills from below")
    print("\t\t1-JAVA")
    print("\t\t2-C++")
    print("\t\t3-HTML")
    print("\t\t4-PYTHON")
    skills=input("Enter your choosed option (serial number):")
    while skills not in libskills:
        print("Chose a valid option!")
        skills=input("\nEnter your choosed option (serial number):")

