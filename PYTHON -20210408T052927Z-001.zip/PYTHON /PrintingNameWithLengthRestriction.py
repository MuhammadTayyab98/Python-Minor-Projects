name = input("Enter your name here  : ")
if (len(name) < 10):
    print(name)
else:
    print("Your name has more than 10 chracters !")