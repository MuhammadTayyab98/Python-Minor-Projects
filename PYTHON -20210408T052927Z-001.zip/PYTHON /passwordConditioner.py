print("If your choosed password will be 6<passord<16 then 'ok' otherwise message will be printed to reset your password.")
password = input("Create a password: ")
if len(password) > 6 and len(password) < 16:
    print("Password Accepted!")

''' creating a while loop for the reprinting the creating password option for the user if user's password doesn't 
    meet the requirements'''

while len(password) <= 6 or len(password) >= 16:
    print("Your password should have characters less than 16 and more than 6.")
    password = input("Create again : ")
    if len(password) > 6 and len(password) < 16:
        print("Password Accepted!")
    else:
        print("")
