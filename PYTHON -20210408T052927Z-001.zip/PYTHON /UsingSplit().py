# split method makes a list of all elements in a specified string as below

a = "Tayyab Irfan is a CS student"
print(a.split(" "))