# starting
guesses = 0
print("Let's  began the GTW !")
print("You have 10 number of guesses! \n")

# applying the loop for generation of statements
while(guesses<10):
    guessnum = int(input("Guess the number: "))
    if(guessnum>1):
        print("\t Guess small! \n")
    elif(guessnum<1):
        print("\t Guess large! \n")
    else:
        print("\t You won! \n")
        print(guesses, " guesses took you to win the game!")
        break

    # calcullation of number of guesses
    print("________________", 9-guesses, " guesses left! ________________")
    guesses = guesses + 1

# game over scenario
if(guesses>9):
    print("\t \tGame Over, Guesses finished!")