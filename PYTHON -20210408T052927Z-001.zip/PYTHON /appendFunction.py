list1 = [1,2,3,4,5,6]
list2 = [7,8,9]

# append function --> append means shamil krna
list1.append(list2)
print(f'List1 after appending with list2 is {list1}')
