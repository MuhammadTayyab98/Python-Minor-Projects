print("Hello World!")
print("Hello Tayyab")


