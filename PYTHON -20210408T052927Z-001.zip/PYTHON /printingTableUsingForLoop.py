num = int(input("Enter number of which you wanted print the table: "))
limit = int(input(f'Print table of {num} till : '))
print(f'\nTable of {num} till {limit} is: \n')
for i in range(1, limit):
    print(f'{num} x {i} = {num*i}')