'''
This program will generate a perfect password for the
    user depending on the number of chracters
    entered by the user
'''

import string
import random

s1 = string.ascii_uppercase

s2 = string.ascii_lowercase

s3 = string.digits

s4 = string.punctuation

passLen = int(input("Enter the length of the password here : "))
s=[]
s.extend(list(s1))
s.extend(list(s2))
s.extend(list(s3))
s.extend(list(s4))

random.shuffle(s)
print("Your password would be : ")
print("".join(s[0:passLen]))