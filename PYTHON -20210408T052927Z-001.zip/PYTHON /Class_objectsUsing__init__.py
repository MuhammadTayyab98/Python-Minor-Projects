# decelaring a class using __init__ function
# declaring a class and its objects

class student():
    def __init__(self,name,age,fathername,std,favNum,lang):
        self.name=name
        self.age=age
        self.fathername=fathername
        self.std=std
        self.favNum=favNum
        self.lang=lang

# the class has been created successfully, I can now call this in other file or other class (or function)

# Calling the class in the below class
student1 = student("tayyab",17,"irfan","1st yr",5,"java")
student2 = student("khizar",18,"hayat","1st yr",7,"python")
student3 = student("khaleeq",19,"ahmed","1st yr",6,"html")

# printing the data for the class student() for student1
print("\n\nDATA FOR FIRST STUDENT:")
print(student1.name)
print(student1.age)

# printing the data of class student() for student2
print("\n\nDATA FOR SECOND STUDENT:")
print(student2.name)
print(student2.age)

# printing the data of class student() for student2
print("\n\nDATA FOR THIRD STUDENT:")
print(student3.name)
print(student3.age)