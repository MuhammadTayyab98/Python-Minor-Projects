'''
format assigns the value of variables used in the place of x&y in format(x,y)
'''

num1 = 2
num2 = 4
sum1 = num1+num2
print("Sum of {} and {} is".format(num1, num2),sum1)