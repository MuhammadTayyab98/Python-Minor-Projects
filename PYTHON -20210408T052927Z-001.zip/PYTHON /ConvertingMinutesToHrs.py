minutes = int(input("Enter minutes:"))
hours = float(minutes/60)
print("Minutes are: ", minutes, " minutes")
print("Hours are: ", hours, " hrs")