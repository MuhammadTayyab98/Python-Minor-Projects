# importing the time library
import time
# declaring a variable to be printed in the place of stdTime
localtime = time.asctime(time.localtime(time.time()))
# printing the time through printing the local variable
print(localtime)
