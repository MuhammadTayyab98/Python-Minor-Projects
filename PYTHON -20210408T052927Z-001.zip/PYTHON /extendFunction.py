#  extend fucntion --> extend means barhana
list1 = [1,2,3,4,5]
list2 = [6,7,8]
list1.extend(list2)
print(f'List1 after extending with List2 is {list1}')