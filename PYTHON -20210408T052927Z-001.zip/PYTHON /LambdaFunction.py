sum = lambda a, b: a+b
print("Sum is", sum(a=int(input("a = ")) , b=int(input("y = "))))
