print("Enter age, if your age is 18 then you will find a messege of confirmed otherwise you will be appologized! ")
i=int(input("Enter your age: "))
if(i>=18 and i<20):
    if(i>=18 and i<19):
        if(i==18):
            print("Confirmed!")
else:
    print("sorry!")