# declaring the class
class student():
    pass

# declaring the object: object  means the derived attributes of a class
mt = student()
mt.name = "Tayyab"
mt.number = 32623
mt.id = 231
mt.char = "mtmtmt"

# printing the class's objects
print(mt.name)
print(mt.number)
print(mt.id)
print(mt.char)