# python program password reset


password = input("password : ")
if (password == "12345"):
    print("WELOCME :)")
else:
    decision = input("Press '1' to try again and '0' for password reset : ")
    if(decision==1):
        print(input("Enter password here : "))
        if (password == "12345"):
            print("WELOCME :)")
        else:
            decision = input("Press 'A' to try again : ")
            decision2 = input("Forgot password ? Press B to reset password settings : ")
            if (decision==1):
                password = input("Enter password here : ")
    elif(decision==0):
        print("Welcome to reset password settings !")
        task = input("Press '1' to go to privacy manager where you can reset password or press '0' to exit : ")
        if(task==1):
            print("WELCOME !!! We will contact you soon :)")
        elif(task==0):
            print("BYE")
