'''
  I will try to print sum of a 'str' and an 'int'
 which will surely throw an error XD
 so that we will using try-Except handling in order to avoid the error
 the error will be printed as a string in the terminal and will not interrupt our program
 to be executed!
'''

num1 = 2
num2 = "jahsadv"

try:
    sum1 = print(f'\n Sum of {num1} and {num2} is {num2 + num1}')
except Exception as e:
    print("ERROR as str:", e)

print("\nThis Line is very Important, I have to print it anyways!!!")

